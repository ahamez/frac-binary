
#ifndef FIACRE_H
#define FIACRE_H

typedef int bool;

/* macros and primitives for tts .c files */

/* for sprint_state */

/* as of frac 2.3.0, value printer is parameterized for fiacre or json, using that structure: */
struct pmap {
  /* queue left bracket; separator; right bracket */
  struct {struct { int z; char *s; } l; struct { int z; char *s; } s; struct { int z; char *s; } r;  } q;
  /* array left bracket; separator; right bracket */
  struct {struct { int z; char *s; } l; struct { int z; char *s; } s; struct { int z; char *s; } r;  } a;
  /* record left bracket; binding symbol; separator; right bracket */
  struct {struct { int z; char *s; } l; struct { int z; char *s; } b;  struct { int z; char *s; } s; struct { int z; char *s; } r;  } r;
  /* 1-ary construction left bracket; binding symbol; rightbracket */
  struct {struct { int z; char *s; } l; struct { int z; char *s; } b; struct { int z; char *s; } r;  } c;
  /* name formatting: extra chars % name size and format string */
  struct { int z; char *f; } n;
};
const struct pmap jsonPmap = {{{1,"["},{1,","},{1,"]"}},{{1,"["},{1,","},{1,"]"}},{{1,"{"},{1,":"},{1,","},{1,"}"}},{{1,"{"},{1,":"},{1,"}"}},{2,"\"%s\""}};
const struct pmap fcrPmap   = {{{2,"{|"},{1,","},{2,"|}"}},{{1,"["},{1,","},{1,"]"}},{{1,"{"},{1,"="},{1,","},{1,"}"}},{{0,""},{1,"("},{1,")"}},{0,"%s"}};

/* put symbol/value/name */
#define PUTS(x) {avail -= x.z; if (avail>=0) {buff += sprintf(buff,"%s",x.s);}}
#define PUTV(f,v) {avail -= sprintf(tmpbuff,f,v); if (avail>=0) {buff += sprintf(buff,f,v);}}
#define PUTN(sz,x,n) {avail -= sz + x.z; if (avail>=0) {buff += sprintf(buff,x.f,n);}}

/* old macros for frac <= 2.2.8; kept so that old tts descriptions can still be compiled */
#define CATI(z,s) {avail -= z; if (avail<1) {return -1;} else {strcat(buff,s);}}
#define CATV(f,v) {sprintf(tmpbuff,f,v); avail -= strlen(tmpbuff); if (avail<1) {return -1;} else {strcat(buff,tmpbuff);}}

/* for interval arithmetics */

#define XINTERVAL {fprintf(stderr,"interval value out of range\n"); fflush(stderr); exit(1);}

#define IMINUS(x,l,h)  ({int r= -x; if (r<l || r>h) {XINTERVAL;} r;})
#define ICOERCE(x,l,h) ({int r=x; if (r<l || r>h) {XINTERVAL;} r;})
#define IADD(x,y,l,h)  ({int r=x + y; if (r<l || r>h) {XINTERVAL;} r;})
#define ISUB(x,y,l,h)  ({int r=x - y; if (r<l || r>h) {XINTERVAL;} r;})
#define IMUL(x,y,l,h)  ({int r=x * y; if (r<l || r>h) {XINTERVAL;} r;})
#define IDIV(x,y,l,h)  ({int r=x / y; if (r<l || r>h) {XINTERVAL;} r;})
#define IMOD(x,y,l,h)  ({int r=x % y; if (r<l || r>h) {XINTERVAL;} r;})

/* for natural integer arithmetics */

#define XNATURAL {fprintf(stderr,"nat integer out of range\n"); fflush(stderr); exit(1);}

#define NMINUS(x)  ({int r= -x; if (r<0) {XNATURAL;} r;})
#define NCOERCE(x) ({int r=x; if (r<0) {XNATURAL;} r;})
#define NADD(x,y)  ({int r=x + y; if (r<0) {XNATURAL;} r;})
#define NSUB(x,y)  ({int r=x - y; if (r<0) {XNATURAL;} r;})
#define NMUL(x,y)  ({int r=x * y; if (r<0) {XNATURAL;} r;})
#define NDIV(x,y)  ({int r=x / y; if (r<0) {XNATURAL;} r;})
#define NMOD(x,y)  ({int r=x % y; if (r<0) {XNATURAL;} r;})

/* for queues */

#define XQUEUE {fprintf(stderr,"queue exception\n"); fflush(stderr); exit(1);}

#define EMPTY(q)          ((q).len==0)
#define FULL(q,n)         ((q).len==(n))
#define FIRST(q)          ({if (EMPTY(q)) {XQUEUE;} (q).at[0];})
#define LENGTH(q)         ((q).len)
/* beware: must work even if r=q */
#define ENQUEUE(r,q,e,sz) {int i; \
                           if (FULL(q,sz)) {XQUEUE;}; \
			   for (i=0; i<(q).len; i++) {(r).at[i]=(q).at[i];}; \
			   (r).at[i]=(e); \
                           (r).len = (q).len + 1;}
#define APPEND(r,q,e,sz)  {int i;		      \
                           if (FULL(q,sz)) {XQUEUE;}; \
			   for (i=(q).len; i>0; i--) {(r).at[i]=(q).at[i-1];}; \
			   (r).at[i]=(e); \
			   (r).len = (q).len + 1;}
#define DEQUEUE(r,q)      {int i; \
                           if (EMPTY(q)) {XQUEUE;}; \
			   (r).len = (q).len - 1; \
			   for (i=0; i<(r).len; i++) {(r).at[i]=(q).at[i+1];}}

/* for other dymanic errors */

#define FAILWITH(m) {fprintf(stderr,m); fprintf(stderr,"\n"); fflush(stderr); exit(1);}

#endif
