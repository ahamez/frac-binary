
#ifdef __sparc
#include <sys/int_types.h>
#else
#include <stdint.h>
#endif

#include <limits.h>


////////////////////////////////////////////////////////////////////////////////
// controls

static int compressf = 1;   /* does compress if 1, overwritten by set_compression if called */

/* enables/disables vbe compression */
int set_compression (int f) {
  compressf = f;
  return 0;
}

////////////////////////////////////////////////////////////////////////////////

// Works char by char
static
size_t
rle(size_t size, char* src, char* dest) {
  const char* orig = dest;
  size_t i = 0;
  for( i = 0 ; i < size ; ++i ) {
    unsigned char run_length = 1;
    while( i+1 < size && src[i] == src[i+1] && run_length < UCHAR_MAX ) {
      ++run_length;
      ++i;
    }
    *dest++ = run_length;
    *dest++ = src[i];
  }
  return dest - orig;
}

static
size_t
unrle(size_t size, char* src, char* dest) {
  const char* orig = src;
  while ((src - orig) < size) {
    const unsigned char run_length = *src++;
    size_t j = 0;
    for(j = 0; j < run_length; ++j ) {
      *dest++ = *src;
    }
    ++src;
  }
  return src - orig;
}

////////////////////////////////////////////////////////////////////////////////
// variable byte encoding/decoding

static // inline
size_t
compress_unsigned_long(unsigned long n, char* data) {
  const char* orig = data;
  while (n  > 127) {
    *data++ = (n & 127)|128;
     n >>= 7;
  }
  *data++ = n;
  return data - orig;
}

static // inline
size_t
uncompress_unsigned_long(unsigned long* val, char* data) {
  size_t size = 0;
  unsigned long x = 0;   /* must hold an unsigned long */
  unsigned long b = 0;   /* segfaults if int ... */
  int shift = 0;
   
  while ((b = *data++) > 127) {
    ++size;
    x |= (b & 127) << shift;
    shift += 7;
  }
  *val = x | (b << shift);
  return ++size;
}

static inline
size_t
compress_long (long n, char *data) {
  return (n >= 0) ? compress_unsigned_long(2*n, data) 
                  : compress_unsigned_long((-2*n)-1, data)
                  ;
}

static inline
size_t
uncompress_long(long* val, char* data) {
  unsigned long n;
  const size_t j = uncompress_unsigned_long(&n, data);
  *val = (n % 2) ? -((n+1)/2)
                 : n/2
                 ;
  return j;
}

static // inline
size_t
compress_unsigned_int(unsigned int n, char* data) {
  const char* orig = data;
  while (n  > 127) {
    *data++ = (n & 127)|128;
     n >>= 7;
  }
  *data++ = n;
  return data - orig;
}

static // inline
size_t
uncompress_unsigned_int(unsigned int* val, char* data) {
  size_t size = 0;
  unsigned int x = 0;
  unsigned int b = 0;
  int shift = 0;
   
  while ((b = *data++) > 127) {
    ++size;
    x |= (b & 127) << shift;
    shift += 7;
  }
  *val = x | (b << shift);
  return ++size;
}

static inline
size_t
compress_int(int n, char *data) {
  return (n >= 0) ? compress_unsigned_int(2*n, data) 
                  : compress_unsigned_int((-2*n)-1, data)
                  ;
}

static inline
size_t
uncompress_int(int* val, char* data) {
  unsigned int n;
  const size_t j = uncompress_unsigned_int(&n, data);
  *val = (n % 2) ? -((n+1)/2)
                 : n/2
                 ;
  return j;
}

static // inline
size_t
compress_unsigned_short(unsigned short n, char* data) {
  const char* orig = data;
  while (n  > 127) {
    *data++ = (n & 127)|128;
     n >>= 7;
  }
  *data++ = n;
  return data - orig;
}

static // inline
size_t
uncompress_unsigned_short(unsigned short* val, char* data) {
  size_t size = 0;
  unsigned short x = 0;
  unsigned short b = 0;
  int shift = 0;
   
  while ((b = *data++) > 127) {
    ++size;
    x |= (b & 127) << shift;
    shift += 7;
  }
  *val = x | (b << shift);
  return ++size;
}

static inline
size_t
compress_short(short n, char *data) {
  return (n >= 0) ? compress_unsigned_short(2*n, data) 
                  : compress_unsigned_short((-2*n)-1, data)
                  ;
}

static inline
size_t
uncompress_short(short* val, char* data) {
  unsigned short n;
  const size_t j = uncompress_unsigned_short(&n, data);
  *val = (n % 2) ? -((n+1)/2)
                 : n/2
                 ;
  return j;
}


////////////////////////////////////////////////////////////////////////////////
/* pack/unpack for numeric types */

#ifdef __sparc
// integer pointers must be aligned on 4 bytes
#define PACK(to,from,ty) {memcpy(to,&from,sizeof(ty));}
#define UNPACK(to,from,ty) {memcpy(to,from,sizeof(ty));}
#else
#define PACK(to,from,ty) {*(ty *)to=from;}
#define UNPACK(to,from,ty) {*to = *(ty *)from;}
#endif

static inline
size_t
pack_bool(bool val, char* data) {
  *((unsigned char*)data) = val;
  return sizeof(unsigned char);
}

static inline
size_t
pack_unsigned_int(unsigned int val, char* data) {
  if (compressf) {
    return compress_unsigned_int(val, data);
  } else {
    PACK(data,val,unsigned int);
    return sizeof(unsigned int);
  }
}

static inline
size_t
pack_long(long val, char* data) {
  if (compressf) {
    return compress_long(val, data);
  } else {
    PACK(data,val,long);
    return sizeof(long);
  }
}

static inline
size_t
pack_int(int val, char* data) {
  if (compressf) {
    return compress_int(val, data);
  } else {
    PACK(data,val,int);
    return sizeof(int);
  }
}

static inline
size_t
pack_unsigned_char(unsigned char val, char* data) {
  *((unsigned char*)data) = val;
  return sizeof(unsigned char);
}

static inline
size_t
pack_char(char val, char* data) {
  *data = val;
  return sizeof(char);
}

static inline
size_t
pack_unsigned_short(unsigned short val, char* data) {
  if (compressf) {
    return compress_unsigned_short(val,data);
  } else {
    PACK(data,val,unsigned short);
    return sizeof(unsigned short);
  }
}

static inline
size_t
pack_short(short val, char* data) {
  if (compressf) {
    return compress_short(val,data);
  } else {
    PACK(data,val,short);
    return sizeof(short);
  }
}

static inline
size_t
unpack_bool(bool* val, char* data) {
  *val = (bool)*data;
  return sizeof(unsigned char);
}

static inline
size_t
unpack_unsigned_char(unsigned char* val, char* data) {
  *val = (unsigned char)*data;
  return sizeof(unsigned char);
}

static inline
size_t
unpack_char(char* val, char* data) {
  *val = *data;
  return sizeof(char);
}

static inline
size_t
unpack_unsigned_short(unsigned short* val, char* data) {
  if (compressf) {
    return uncompress_unsigned_short(val, data);
  } else {
    UNPACK(val,data,unsigned short);
    return sizeof(unsigned short);
  }
}

static inline
size_t
unpack_short(short* val, char* data) {
  if (compressf) {
    return uncompress_short(val, data);
  } else {
    UNPACK(val,data,short);
    return sizeof(short);
  }
}

static inline
size_t
unpack_unsigned_int(unsigned int* val, char* data) {
  if (compressf) {
    return uncompress_unsigned_int(val, data);
  } else {
    UNPACK(val,data,unsigned int);
    return sizeof(unsigned int);
  }
}

static inline
size_t
unpack_long(long* val, char* data) {
  if (compressf) {
    return uncompress_long(val, data);
  } else {
    UNPACK(val,data,long);
    return sizeof(long);
  }
}

static inline
size_t
unpack_int(int* val, char* data) {
  if (compressf) {
    return uncompress_int(val, data);
  } else {
    UNPACK(val,data,int);
    return sizeof(int);
  }
}

////////////////////////////////////////////////////////////////////////////////
// Hash stuff

// always_inline apparently not available in gc 2.7.2 ...
#if defined(__GNUC__) && __GNUC__ > 2
#define	FORCE_INLINE inline __attribute__((always_inline))
#else
#define	FORCE_INLINE inline
#endif

static inline uint32_t rotl32 ( uint32_t x, int8_t r ) {
  return (x << r) | (x >> (32 - r));
}

static inline uint64_t rotl64 ( uint64_t x, int8_t r ) {
  return (x << r) | (x >> (64 - r));
}

#define	ROTL32(x,y)	rotl32(x,y)
#define ROTL64(x,y)	rotl64(x,y)

#define BIG_CONSTANT(x) (x##LLU)


//-----------------------------------------------------------------------------
// Block read - if your platform needs to do endian-swapping or can only
// handle aligned reads, do the conversion here

FORCE_INLINE uint32_t getblock ( const uint32_t * p, int i ) {
  return p[i];
}

//-----------------------------------------------------------------------------
// Finalization mix - force all bits of a hash block to avalanche

FORCE_INLINE uint32_t fmix ( uint32_t h ) {
  h ^= h >> 16;
  h *= 0x85ebca6b;
  h ^= h >> 13;
  h *= 0xc2b2ae35;
  h ^= h >> 16;

  return h;
}

//-----------------------------------------------------------------------------

void MurmurHash3_x86_32 ( const void * key, int len,
                          uint32_t seed, void * out ) {
  const uint8_t * data = (const uint8_t*)key;
  const int nblocks = len / 4;

  uint32_t h1 = seed;

  uint32_t c1 = 0xcc9e2d51;
  uint32_t c2 = 0x1b873593;

  //----------
  // body

  const uint32_t * blocks = (const uint32_t *)(data + nblocks*4);

  int i = 0;
  for(i = -nblocks; i; i++) {
    uint32_t k1 = getblock(blocks,i);

    k1 *= c1;
    k1 = ROTL32(k1,15);
    k1 *= c2;
    
    h1 ^= k1;
    h1 = ROTL32(h1,13); 
    h1 = h1*5+0xe6546b64;
  }

  //----------
  // tail

  const uint8_t * tail = (const uint8_t*)(data + nblocks*4);

  uint32_t k1 = 0;

  switch(len & 3) {
  case 3: k1 ^= tail[2] << 16;
  case 2: k1 ^= tail[1] << 8;
  case 1: k1 ^= tail[0];
          k1 *= c1; k1 = ROTL32(k1,16); k1 *= c2; h1 ^= k1;
  };

  //----------
  // finalization

  h1 ^= len;

  h1 = fmix(h1);

  *(uint32_t*)out = h1;
} 
