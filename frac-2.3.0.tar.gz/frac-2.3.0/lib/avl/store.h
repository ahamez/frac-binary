#ifndef _STORE_H_
#define _STORE_H_

#include <stddef.h>

typedef ptrdiff_t key;

/* Warning! The allocated node is in fact an avl followed by the stored data
   Thus, the real size of an avl is sizeof(avl) + get_size(data)
*/
typedef struct __attribute__ ((__packed__)) avl {
  struct avl *left;
  struct avl *right;
  unsigned char height;
} avl;

typedef struct
{
  avl*    avl;
  char*   pack_buffer;
  void*   last_data;
  void*   last_data_key;
  void    (*pack_data)();
  void    (*unpack_data)();
  size_t  (*size_data)();
} storage_t;

/* define SHARE iff library supports sharing */
#define SHARE

#include "avl.c"

#endif // _STORE_H_
