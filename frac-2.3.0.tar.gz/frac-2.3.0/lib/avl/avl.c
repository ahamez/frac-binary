/* avl's with state packing */

/* define SETJMP if state comparison is expensive */
// #define SETJMP

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef SETJMP
#include <setjmp.h>
#endif
#ifndef MINGW
#include <sys/types.h>
#include <sys/mman.h>
#include <unistd.h>
#ifdef __MACH__
#include <mach/vm_statistics.h>
#endif
#endif
#include "store.h"


/* declarations ----------------------------------------------------------------------------- */

// Memory management
#ifndef MINGW
static char* current_start = 0;
static size_t current_used = 0;
#ifdef __MACH__
// useful to profile memory usage on MacOS X
static const int vm_tag = VM_MAKE_TAG(240);
#else
static const int vm_tag = -1;
#endif
static const size_t block_size = 16777216;
#endif

/* packing/unpacking routines --------------------------------------------------------------- */

/* creates a string from the state packed in pack_buffer (called if state found new) */
static char* copy_from_pack_buffer(storage_t* st, char* to) {
  const size_t size = st->size_data(st->pack_buffer);
  memcpy(to, st->pack_buffer, size);
  return to;
}

int compare_packed_data (storage_t *st, char* lhs, char* rhs) {
  const int test = memcmp(lhs, rhs, st->size_data (lhs));
  return (test == 0) ? 0 : ((test < 0) ? -1 : 1);
}


#ifdef MINGW
#define alloc(size) (malloc(size))
#else
static char* alloc(size_t size) {
  char* previous_start = 0;
  size_t previous_used  = current_used;
  // do we need to allocate more memory?
  if (block_size - current_used < size) {
    char* new_start = (char *)mmap(0, block_size, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, vm_tag, 0);
    if (new_start == MAP_FAILED)
      return NULL;
    madvise(new_start, block_size, MADV_RANDOM);
    // are the old block and the new block contiguous?
    if ((current_start + block_size) == new_start)
      previous_start = current_start;
    current_start = new_start;
    current_used = 0;
  }
  if (previous_start) { // contiguous blocks
    // don't forget to remove the size of what is stored in the old block
    current_used = size - (block_size - previous_used);
    return previous_start + previous_used;
  } else {
    previous_used = current_used; // beginning of the 'allocated' block
    current_used += size;
    return current_start + previous_used;
  }
}
#endif



/* avl storage routines --------------------------------------------------------------------- */

#define Height(P) ((P==NULL) ? 0 : (P)->height)
#define Data(node)            ((char*)node + sizeof(avl))

#define Max(x,y) (((x)>(y)) ? (x) : (y))
#define Abs(x) (((x)<0) ? -(x) : (x))

static avl *SingleRotateWithLeft(avl *K2) {
  avl *K1;
  K1 = K2->left;
  K2->left = K1->right;
  K1->right = K2;
  K2->height = Max(Height(K2->left), Height(K2->right)) + 1;
  K1->height = Max(Height(K1->left), K2->height) + 1;
  return K1;
}

static avl *SingleRotateWithRight(avl *K1) {
  avl *K2;
  K2 = K1->right;
  K1->right = K2->left;
  K2->left = K1;
  K1->height = Max(Height(K1->left), Height(K1->right)) + 1;
  K2->height = Max(Height(K2->right), K1->height) + 1;
  return K2;
}

static avl *DoubleRotateWithLeft(avl *K3) {
  K3->left = SingleRotateWithRight(K3->left);
  return SingleRotateWithLeft(K3);
}

static avl *DoubleRotateWithRight (avl *K1) {
  K1->right = SingleRotateWithLeft(K1->right);
  return SingleRotateWithRight(K1);
}


#ifdef SETJMP
static jmp_buf env;
#else
static int Lookup (storage_t* st, void *e, avl *P, void ** result) {
  avl *T=P;
  while (1) {
    if (T == NULL) {
      return 0;
    } else {
      switch (compare_packed_data(st,e,Data(T))) {
      case -1 : 
	T=T->left;
	break;
      case  0 :
	*result = Data(T);
	return 1;
	break;
      case  1 :
	T=T->right;
	break;
      }
    }
  }
}
#endif

static avl *Insert (storage_t* st, void *e, avl* T, void ** result) {
  if (T == NULL) {
    T = (avl*)alloc(sizeof(avl) + st->size_data(st->pack_buffer));
    if (T == NULL)
      {fprintf(stderr,"tts exception: out of memory\n"); fflush(stderr); exit(1);}
    else {
      T->height = 1;
      T->left = T->right = NULL;
      copy_from_pack_buffer(st, ((char*)T + sizeof(avl)));
      *result=Data(T);
    }
  } else {
    switch (compare_packed_data(st,e,Data(T))) {
    case -1 : 
      T->left = Insert(st, e, T->left, result);
      if (Height(T->left) - Height(T->right) == 2)
	if (Height(T->left->right) < Height(T->left->left)) /* eqv. (compare_states(e,Data(T->left)) < 0) */
	  T = SingleRotateWithLeft(T);
	else
	  T = DoubleRotateWithLeft(T);
      T->height = Max(Height(T->left), Height(T->right)) + 1;
      break;
#ifdef SETJMP
    case  0 :
      *result = Data(T);
      longjmp(env,1);
      break;
#endif
    case  1 :
      T->right = Insert(st, e, T->right, result);
      if (Height(T->right) - Height(T->left) == 2)
	if (Height(T->right->right) > Height(T->right->left)) /* eqv. (compare_states(e,Data(T->right)) > 0) */
	  T = SingleRotateWithRight(T);
	else
	  T = DoubleRotateWithRight(T);
      T->height = Max(Height(T->left), Height(T->right)) + 1;
      break;
    }
  }
  return T;
}

/* SearchInsert (combines lookup and add) */
static void * SearchInsert (storage_t* st, void *e) {
  void * result;
#ifdef SETJMP
  if (!setjmp(env))
#else
    if (!Lookup(st, e, st->avl, &result))
#endif
      st->avl = Insert (st, e, st->avl, &result);
  return result;
}


/* for debug and statictics */

/* size of avl */
static long avlsize = 0;
static long totalavlsize = 0;
static long avlnodes = 0;

/* returns height or -1 if avl property not met */
static int isAvl (storage_t* st, avl *t) {
  int hl, hr;
  if (t==NULL) return 0;
  avlsize +=  sizeof(avl) + st->size_data((char*)t + sizeof(avl));
  avlnodes++;
  if ((hl = isAvl (st , t->left)) < 0) return -1;
  if ((hr = isAvl (st, t->right)) < 0) return -1;
  if (Abs(hl - hr) > 1) return -1;  /* bad balance */
  if (t->height == 1 + Max(hl,hr)) return t->height;
  return -1;  /* bad recorded height */
}

/* checks isAvl and computes size */
static int check_avl (storage_t* st, char *tag) {
  int h;
  avlnodes = 0;
  avlsize = 0;
  fflush(stderr);
  if ((h = isAvl(st, st->avl)) < 0) {
    fprintf(stderr,"\risavl = false\n");
  } else {
    if (h) fprintf(stderr,"\r%s: isavl = true, %ld nodes, size=%ld, height=%d\n", tag, avlnodes, avlsize, h);
    totalavlsize += avlsize;
  }
  fflush(stderr);
  return h;
}



/* storage api routines --------------------------------------------------------------------- */

static int open_storage() {
#ifndef MINGW
  current_start = mmap(0, block_size, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE,  vm_tag, 0);
  if (current_start == MAP_FAILED) return 1;
  madvise(current_start, block_size, MADV_RANDOM);
#endif
  return 0;
}

static storage_t init_storage (size_t size, int (*compare_)(), void  (*pack_)(), void  (*unpack_)(), size_t  (*size_)()) {
  storage_t st;
  st.avl = NULL;
  st.pack_buffer = /* alloc(size * 4); */ alloc(size*2 + 16 );
  st.last_data = alloc(size);
  st.last_data_key = 0;
  st.pack_data = pack_;
  st.unpack_data = unpack_;
  st.size_data = size_;
  return st;
}

static int close_storage(int debug) {
  if (debug) fprintf(stderr,"dataspace size = %ld\n",totalavlsize);
  return 0;
}

static int finalize_storage(char *tag, int debug, storage_t* st) {
  if (debug) check_avl (st,tag);
  return 0;
}

static key store_data (storage_t* st, void* data) {
  st->pack_data(data, st->pack_buffer);
  return (key)(SearchInsert(st, st->pack_buffer) - (long)(st->pack_buffer));
}

static void* lookup_data (storage_t* st, key k) {
  char *from = st->pack_buffer + k;
  if (st->last_data_key == from) {
    return st->last_data;               /* cached; last value kept there */
  } else {
    st->last_data_key = from;           /* miss: unpack from into last_data */
    st->unpack_data(st->last_data, from);
    return st->last_data;
  }
}

#ifdef SHARE
static size_t pack_key (storage_t *st, void *from, char *to) {
  return pack_long(store_data(st,from), to);
}

static size_t unpack_key (storage_t *st, void *to, char *from) {
  long offset;
  size_t res = unpack_long(&offset, from);
  st->unpack_data(to, st->pack_buffer + offset);
  return res;
}
#endif
